const { ChatInputCommandInteraction, Client, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");
//const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'avatar',
  description: 'Display your avatar or the avatar of the user you mentioned.',
  options: [
    {
      name: 'user',
      description: 'The user whose avatar you want to display',
      type: ApplicationCommandOptionType.User,
      required: false
    }
  ],
  execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const AvatarEmbed = new EmbedBuilder()
      .setTitle(`${user.username}'s Avatar`)
      .setImage(user.displayAvatarURL({ dynamic: true, size: 4096 }))

    interaction.reply({ embeds: [AvatarEmbed] });
  }
};