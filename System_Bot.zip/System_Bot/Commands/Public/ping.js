const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ChatInputCommandInteraction, Client } = require('discord.js');
const EmbedsColor = require("../../JSON/config.json");
module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('pong.'),

        /**
         * @param {ChatInputCommandInteraction} interaction 
         * @param {Client} client 
         */

        async execute(interaction, client) {
        	let circle;
if(client.ws.ping > 300) { circle = ""; }
if(client.ws.ping < 200) { circle = ""; }
if(client.ws.ping < 100) { circle = ""; }
const PingEmbed = new EmbedBuilder()
.setColor("#FFC312")
.setTitle('Pong  !')
.setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.avatarURL({dynamic:true})})
.setDescription(`${circle} My Ping Is : ${client.ws.ping}ms`);

interaction.reply({embeds: [PingEmbed] });
    }

}