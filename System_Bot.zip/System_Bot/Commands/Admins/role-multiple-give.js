const {SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder} = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('role-multiple-give')
    .setDescription('to give a multiple role to a members')
    .addRoleOption(option => option.setName('role-name').setDescription('role you want to give').setRequired(true)),
    async execute(interaction) {
        const { options, guild } = interaction;
        const role  = await interaction.options.getRole('role-name');

   const embed = new EmbedBuilder()
          .setTitle(`**Adding Role for ${interaction.guild.memberCount} **`)
          .setDescription(`**Role : + ${role.name}**`)
        .setColor(`#4cd137`);

        if (!interaction.guild.members.me.permissions.has("MANAGE_ROLES")) {
            embed.setTitle(`**❗️ - I don't have permission to do this action.**`).setDescription().setColor('#EA2027');
            interaction.reply({embeds:[embed]});
            return;
          }
          if (!interaction.member.permissions.has("MANAGE_ROLES")) {
            embed.setTitle(`**❗️ - You don't have permission to do this action.**`).setDescription().setColor('#EA2027');
            interaction.reply({embeds:[embed]});
            return;
          }
          if (role.position >= interaction.member.roles.highest.position) {
            embed.setTitle(`**❗️ - You cannot give someone a higher role than your role**`).setDescription().setColor('#EA2027');
            interaction.reply({embeds:[embed]});
            return;
          }
        
await interaction.reply({embeds:[embed]});

let num = 0;
guild.members.cache.forEach(async m => {
    m.roles.add(role).catch(err => {
    });
    num++;


embed.setTitle(`Add Role for ${num}`)
        await interaction.editReply({ embeds: [embed] });

    });
},
};