const {SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder} = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('role-remove')
    .setDescription('to remove a role to a user')
    .addRoleOption(option => option.setName('role-name').setDescription('role you want to remove').setRequired(true))
    .addUserOption(option => option.setName('user-name').setDescription('member of the role you want to remove').setRequired(true)),
    async execute(interaction) {
        const role  = await interaction.options.getRole('role-name');
        const target = await interaction.options.getMember('user-name');

   const embed = new EmbedBuilder()
          .setTitle(`**Removed Role from ${target.user.username}**`)
          .setDescription(`**Role : - ${role.name}**`)
        .setColor(`#EA2027`);

        if (!interaction.guild.members.me.permissions.has("MANAGE_ROLES")) {
            embed.setTitle(`**❗️ - I don't have permission to do this action.**`).setDescription().setColor('#EA2027');
            interaction.reply({embeds:[embed]});
            return;
          }
          if (!interaction.member.permissions.has("MANAGE_ROLES")) {
            embed.setTitle(`**❗️ - You don't have permission to do this action.**`).setDescription().setColor('#EA2027');
            interaction.reply({embeds:[embed]});
            return;
          }
          if (role.position >= interaction.member.roles.highest.position) {
            embed.setTitle(`**❗️ - You cannot give someone a higher role than your role**`).setDescription().setColor('#EA2027');
            interaction.reply({embeds:[embed]});
            return;
          }
        await target.roles.remove(role);
        await interaction.reply({ embeds: [embed] });

    },
};


