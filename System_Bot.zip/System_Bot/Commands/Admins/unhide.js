const { SlashCommandBuilder } = require('@discordjs/builders');
const { Client, ChatInputCommandInteraction, ChannelType, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unhide')
        .setDescription('Unhides the current channel.')
        .addChannelOption(option => option.setName("channel").setDescription("the channel you want to Unhide it.").addChannelTypes(ChannelType.GuildText).setRequired(false)),
    /**
     * @param {ChatInputCommandInteraction} interaction 
     * @param {Client} client
     */
    async execute(interaction, client) {
        const channel = interaction.options.getChannel("channel") || interaction.channel;
        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) return interaction.reply({ content: `❗ - **I don't have permission to \`ManageChannels\`**`, ephemeral: true });
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) return interaction.reply({ content: `❗ - **You don't have permission to use this command**`, ephemeral: true });
        

        await channel.permissionOverwrites.edit(interaction.guild.id, { 
            ViewChannel: true
        });

            await interaction.reply({ content: `**👀 - Successfully unhide this channel :** <#${channel.id}>` });
    },
};