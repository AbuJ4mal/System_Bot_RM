const { SlashCommandBuilder } = require('@discordjs/builders');
const { Client, ChatInputCommandInteraction, ChannelType, PermissionsBitField } = require('discord.js');
const fs = require("fs")

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unlock')
        .setDescription('Unlock the current channel.')
        .addChannelOption(option => option.setName("channel").setDescription("The channel you want to unlock it").addChannelTypes(ChannelType.GuildText).setRequired(false)),
    /**
     * @param {ChatInputCommandInteraction} interaction 
     * @param {Client} client
     */
    async execute(interaction, client) {
        const channel = interaction.options.getChannel("channel") || interaction.channel;
        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) return interaction.reply({ content: `❗ - **I don't have permission to \`ManageChannels\`**`, ephemeral: true });
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) return interaction.reply({ content: `❗ - **You don't have permission to use this command**`, ephemeral: true });
        
const channelPermissions = channel.permissionsFor(interaction.guild.id);

        await channel.permissionOverwrites.edit(interaction.guild.id, { 
            SendMessages: null
        });

            interaction.reply({ content: `**🔓 - Successfully unlock this channel :** <#${channel.id}>` });
        },
    };

//|| !interaction.member.roles.cache.get(Accpeted_Role)
