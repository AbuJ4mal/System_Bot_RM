const { SlashCommandBuilder, PermissionsFlagsBits, ChatInputCommandInteraction, Client } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("unban a member")
    .addUserOption(option =>
      option
        .setName("user")
        .setDescription("user id to unban")
        .setRequired(true)),
  /**
   * @param {ChatInputCommandInteraction} interaction
   * @param {Client} client
   */
  async execute(interaction) {
    const user = interaction.options.getUser("user");

    if (!interaction.guild.members.me.permissions.has("BAN_MEMBERS")) {
      interaction.reply("**❗️- I don't have permission to do this action.**");
      return;
    }
    if (!interaction.member.permissions.has("BAN_MEMBERS")) {
      interaction.reply("**❗️- You don't have permission to do this action.**");
      return;
    }
    if (user === interaction.guild.members.me) {
      interaction.reply("**❗️- You can't unban yourself.**");
      return;
    }
    if (user === interaction.guild.ownerID) {
          interaction.reply("**❗️- You can't unban the owner.**");
          return;
        }
        if (user === interaction.guild.me) {
                  interaction.reply("**❗️- You can't unban me.**");
                  return;
                }
            

    await interaction.guild.members.unban(user);
    await interaction.reply(`**🛬 - ${user.username} has been unbaned ✅️**`);
  },
};


