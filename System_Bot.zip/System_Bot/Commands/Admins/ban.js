const { SlashCommandBuilder, PermissionsFlagsBits, ChatInputCommandInteraction, Client } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("ban a member")
    .addUserOption(option =>
      option
        .setName("user")
        .setDescription("user to ban")
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName("reason")
        .setDescription("reason for ban")
        .setRequired(false)),
  /**
   * @param {ChatInputCommandInteraction} interaction
   * @param {Client} client
   */
  async execute(interaction) {
    const user = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason") || "No reason provided";
    const target = await interaction.guild.members.fetch(user);

    if (!interaction.guild.members.me.permissions.has("BAN_MEMBERS")) {
      interaction.reply("**❗️- I don't have permission to do this action.**");
      return;
    }
    if (!interaction.member.permissions.has("BAN_MEMBERS")) {
      interaction.reply("**❗️- You don't have permission to do this action.**");
      return;
    }
    if (target === interaction.guild.owner) {
          interaction.reply("**❗️- You can't ban the server owner.**");
          return;
        }
        if (target === interaction.user) {
                  interaction.reply("**❗️- You can't ban yourself.**");
                  return;
                }
                if (target === interaction.guild.me) {
                                  interaction.reply("**❗️- You can't ban me.**");
                                  return;
                                }
                                if (target.roles.highest.position >= interaction.member.roles.highest.position) {
                                                                      interaction.reply("**❗️- You can't ban a member with a higher role than you.**");
                                                                      return;
                                                                    }
                                                                    

    if(!reason) {
    await target.kick({ reason });
    await interaction.reply(`**✈️ - ${user.username} has been banned from the server. ✅️**`);
    }

    await target.ban({ reason });
    await interaction.reply(`**✈️ - ${user.username} has been banned from the server. ✅️** \n Reason : ${reason}`);
  },
};
