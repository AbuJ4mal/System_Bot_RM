const {SlashCommandBuilder, CommandInteraction, PermissionFlagsBits, EmbedBuilder} = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("clear")
        .setDescription("Clear a specific amount of messages from a target or channel.")
        .setDefaultPermission(false)
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Amount of messages to clear.')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(500)
        ),

    async execute(interaction) {
        const {channel, options} = interaction;

        const amount = options.getInteger('amount');

        const messages = await channel.messages.fetch({
            limit: amount + 1,
        });

        if (!interaction.guild.members.me.permissions.has("MANAGE_MESSAGES")) {
            interaction.reply("**❗️- I don't have permission to do this action.**");
            return;
          }
          if (!interaction.member.permissions.has("MANAGE_MESSAGES")) {
            interaction.reply("**❗️- You don't have permission to do this action.**");
            return;
          }
        

            await channel.bulkDelete(amount, true).then(messages => {
                interaction.reply(`**Succesfully deleted ${messages.size} messages from the channel ✅**`);
    });
        }
    }
