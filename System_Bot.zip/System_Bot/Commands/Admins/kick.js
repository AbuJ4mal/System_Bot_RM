const { SlashCommandBuilder, PermissionsFlagsBits, ChatInputCommandInteraction, Client } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("kick a member")
    .addUserOption(option =>
      option
        .setName("user")
        .setDescription("user to kick")
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName("reason")
        .setDescription("reason for kick")
        .setRequired(false)),
  /**
   * @param {ChatInputCommandInteraction} interaction
   * @param {Client} client
   */
  async execute(interaction) {
    const user = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason");
    const target = await interaction.guild.members.fetch(user);

    if (!interaction.guild.members.me.permissions.has("KICK_MEMBERS")) {
      interaction.reply("**❗️- I don't have permission to do this action.**");
      return;
    }
    if (!interaction.member.permissions.has("KICK_MEMBERS")) {
      interaction.reply("**❗️- You don't have permission to do this action.**");
      return;
    }
    
    if(!reason) {
    await target.kick({ reason });
    await interaction.reply(`**✅️ - ${user.username} has been Kicked from the server.**`);
    }

    await target.kick({ reason });
    await interaction.reply(`**✅️ - ${user.username} has been Kicked from the server. \n Reason : ${reason}**`);
  },
};
