const { SlashCommandBuilder, EmbedBuilder, Embed } =  require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('unban-all')
    .setDescription('Unban all Members'),

    async execute(interaction) {
        const { options, guild, ownerId } = interaction;
        const users = await interaction.guild.bans.fetch();
        const ids = users.map(u => u.user.id);

      /*  if(interaction.user.id != ownerId) {
            await interaction.reply({ content: `You have be server owner to use thos command ❌`, ephemeral: true });
        }*/
        if(!users) {
            interaction.reply({ content: `There are no banned users in the guild`,  ephemeral: true });
        }
        await interaction.reply({ content: `Unbanning all users ...`});

        for (const id of ids) {
            await guild.members.unban(id);
        }
        const embed = new EmbedBuilder()
        .setColor("Blue")
        .setDescription(`${ids.length} members have been **unbanned** from this server` );
    await interaction.editReply({ content: ``, embeds : [embed]});
    }
}