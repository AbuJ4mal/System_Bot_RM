const { Message , Client, SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const welcomeSchema = require("../../Models/welcome.js");
const { model, Schema } = require('mongoose');

module.exports = { 
	data: new SlashCommandBuilder()
	.setName("setup-welcome")
	.setDescription("To Setup a Welcome Message")
	.setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
	.addChannelOption(option => 
		option.setName("channel")
		.setDescription("Set Welcome Channel.")
		.setRequired(true)
	)
	.addStringOption(option => 
		option.setName("message")
		.setDescription("Set Welcome Message")
		.setRequired(true)
	)
	.addRoleOption(option =>
		option.setName("auto-role")
		.setDescription("Set Auto Role When New Member Join.")
		.setRequired(true)
	),
	async execute(interaction) {
		const {channel, options} = interaction;
		
		const welcomeChannel = options.getChannel("channel");
		const welcomeMessage = options.getString("message");
		const roleID = options.getRole("auto-role");
		
		if (!interaction.member.permissions.has(PermissionFlagsBits.SendMessages)) {
  			interaction.reply({ content: "I don't have permissions to do this!", ephemeral: true }); 
		}

		try {
			const welcome = await welcomeSchema.findOne({guild: interaction.guild.id});
			if(!welcome) {
				const newWelcome = await welcomeSchema.create({
					guild: interaction.guild.id,
					channel: welcomeChannel.id,
					msg: welcomeMessage,
					role: roleID.id
				});
			}
			interaction.reply({content: "Successfully added welcome message.", ephemeral: true});
		} catch (err) {
			console.error(err);
			interaction.reply({content: "An error occurred while trying to set up the welcome message.", ephemeral: true});
		}
	}
}
