module.exports = {
    Token: process.env.TOKEN,
    Prefix: '#'
}