const { EmbedBuilder, Events } = require("discord.js");
const Schema = require("../Models/welcome.js");

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member) {
    Schema.findOne({ guild: member.guild.id }, async (err, data) => {
      if (!data) return;

      const channel = data.channel;
      const welcomeMessage = data.msg || "Welcome!";
      const role = data.role;

      const welcomeChannel = member.guild.channels.cache.get(channel);
      if (!welcomeChannel) return;

      const welcomeEmbed = new EmbedBuilder()
        .setTitle("**New Member Joined!**")
        .setDescription(welcomeMessage)
        .setColor('GREEN')
        .addFields({ name: "Total Members ➕️", value: `${member.guild.memberCount}` })
        .setTimestamp();

      welcomeChannel.send({ embeds: [welcomeEmbed] });
      
      if (role) {
        const memberRole = member.guild.roles.cache.get(role);
        if (memberRole) {
          member.roles.add(memberRole);
        }
      }
    });
  }
};
