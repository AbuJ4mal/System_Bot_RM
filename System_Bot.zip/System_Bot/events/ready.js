const { Events } = require('discord.js');
const config = require("../JSON/config.json")
const mongoose = require("mongoose")
module.exports = {
    name: Events.ClientReady,
    once: true,
   async execute(client) {
    	/*await mongoose.connect(config.mongoDB);
if(mongoose.connect) {
	console.log("Connected to Mongoose");
	}*/-
        console.log(`Ready! Logged in as ${client.user.tag}`);
    },
};
