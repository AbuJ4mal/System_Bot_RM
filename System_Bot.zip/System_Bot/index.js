const { Client, GatewayIntentBits } = require('discord.js');
const { TOKEN } = require('./JSON/config.json');
const { readdirSync , fs } = require('fs');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages
    ]
});

readdirSync('./handlers').forEach(handler => {
    require(`./handlers/${handler}`)(client);
});


client.on('guildCreate', async (guild) => {
  try {
    // Create a new role with the desired permissions
    const role = await guild.roles.create({
        name: 'BLOCKED',
        permissions: []
    });

    // Disable all permissions for the role
    await role.setPermissions();
    
   
const roleID = role.id;

    console.log(`Role created with ID: ${role.id}`);
  } catch (error) {
    console.error('Error creating role:', error);
  }
});


client.login(TOKEN);