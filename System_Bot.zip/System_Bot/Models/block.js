const { roleID, guild } = require("../../index.js");
const { model, Schema } = require("mongoose");

let BlockedRole = new Schema ({
	guild: guild.id,
	role: roleID
	});
	
	module.exports = model("Blocked" , Blocked);