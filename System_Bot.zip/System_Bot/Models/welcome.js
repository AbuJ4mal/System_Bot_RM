const { model, Schema } = require("mongoose");

let welcomerSchema = new Schema ({
	guild: String,
	channel: String,
	msg: String,
	role: String
	});
	
	module.exports = model("welcome" , welcomerSchema);